from arcgis.gis import GIS
from urllib import parse
import os,re,json,shutil
from pathlib import Path
import boto3, zipfile
from io import BytesIO
import boto3
from botocore.exceptions import ClientError
from arcgis.learn.text import TextClassifier
from fastai.text import defaults
import datetime



def upload_file(file_name, bucket, object_name=None):
    """Upload a file to an S3 bucket

    :param file_name: File to upload
    :param bucket: Bucket to upload to
    :param object_name: S3 object name. If not specified then file_name is used
    :return: True if file was uploaded, else False
    """

    # If S3 object_name was not specified, use file_name
    if object_name is None:
        object_name = file_name

    # Upload the file
    s3_client = boto3.client('s3')
    try:
        response = s3_client.upload_file(file_name, bucket, object_name)
    except ClientError as e:
        print(e)
        return False
    return True

def get_comments(item_id):
    
    gis = GIS()
    comment_texts,comment_ids, comment_owners = [], [], []
    item = gis.content.get(item_id)
    itemid, title, description = item.itemid, item.title, item.description
    tags, comments_enabled = item.tags, item.commentsEnabled

    if not comments_enabled:
        return []
    comments = item.comments

    
    for comment in comments:
        comment_ids.append(comment.get("id"))
        comment_owners.append(comment.get("owner"))
        comment_texts.append(parse.unquote(comment.get("comment")))

    return comment_texts, comment_ids, comment_owners

def check_file_exist(bucket_name, key):
    
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(bucket_name)
    objs = list(bucket.objects.filter(Prefix=key))
    if any([w.key == key for w in objs]):
        return True
    else:
        return False

def empty_dir(path):
    for root, dirs, files in os.walk(path):
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))

def get_model_fromAGOL(model_id):
    
    gis = GIS()
    data_path = Path('/tmp')
    empty_dir(data_path)
    data_item = gis.content.get(model_id)
    if model_id not in os.listdir(data_path):
        print('downloading model from AGOL')
        data_item.download(save_path=data_path)
        print('model downloaded')
        file_name = Path([file_name for file_name in os.listdir(data_path) if file_name.endswith('.dlpk')][0])
        os.rename(data_path/Path(file_name), data_path/Path(model_id))
        return(f'downloaded to local')     
    else: 
        return('model found on local')

def upload_model_to_S3(model_bucket, model_id):
    data_path = Path('/tmp')
    if not check_file_exist(model_bucket, model_id):
        print('uploading model to s3')
        if not upload_file(f'{str(data_path)}/{model_id}', bucket=model_bucket, object_name=model_id):
            return 'uploading to s3 failed'
        
        return('model file uploaded to s3 and deleted from local')

            
    else:
        return('model found on s3')


def extract_model_to_s3(model_bucket, model_id):
        print('starting model download')
        s3_resource = boto3.resource('s3')
        zip_obj = s3_resource.Object(bucket_name=model_bucket, key=model_id)
        buffer = BytesIO(zip_obj.get()["Body"].read())
        
        print('model_downloaded')
        with zipfile.ZipFile(buffer) as z:
            for filename in z.namelist():
                # file_info = z.getinfo(filename)
                if filename.endswith('emd') or filename.endswith('pth'):
                    model_name = filename.split('.')[0]
                    s3_resource.meta.client.upload_fileobj(
                    z.open(filename),
                    Bucket=model_bucket,
                    Key=f'{model_id}_artefacts/{filename}'
                    ) 
        return model_name
                
def check_model_artefacts_on_S3(model_bucket, model_id):
    s3_bucket = boto3.resource('s3').Bucket(model_bucket)
    for object in  s3_bucket.objects.all():
        if object.key.startswith(f'{model_id}_artefacts'):
            return True

    
def get_model_name(model_bucket, model_id):
    s3_bucket = boto3.resource('s3').Bucket(model_bucket)
    for object in  s3_bucket.objects.all():
        if object.key.startswith(f'{model_id}_artefacts'):
            return object.key.split('/')[-1].split('.')[0]

def send_email(message, sns_arn):
        client = boto3.client('sns')
        topic_arn = sns_arn
        client.publish(TopicArn=topic_arn,Message=message)

def get_model_zip(model_bucket, model_id):
    s3 = boto3.client('s3')
    print('starting model download')
    obj = s3.get_object(Bucket=model_bucket, Key=model_id)
    print('converting model to bytestream')
    bytestream = BytesIO(obj['Body'].read())
    print('model_downloaded')
    return bytestream

def get_model_artefacts(model_bucket, model_id):
    s3_bucket = boto3.resource('s3').Bucket(model_bucket)
    for object in  s3_bucket.objects.all():
        if object.key.startswith(f'{model_id}_artefacts'):
            s3_bucket.download_file(object.key,'/tmp/'+object.key.split('/')[-1])
            print(f'{object.key} downloaded')
            
def load_model(model_name):
    print('loading model')
    path = f'/tmp/{model_name}.emd'
    t1 = datetime.datetime.now()
    defaults.cpus=1
    TextClassifiermodel = TextClassifier.from_model(path)
    with open(path) as f:
        emd = json.load(f)
        labels = emd.get('LabelColumns')
    print('model loading time: ', datetime.datetime.now() -t1)
    return TextClassifiermodel, labels
    
def predict(model, txt, labels, threshold=0.5 ):
    print('making prediction')
    t1=datetime.datetime.now()
    predictions = model.predict(txt)
    # print('predictions : ',predictions)
    print('prediction time : ',datetime.datetime.now()-t1)
    comments, classes, toxic_list, scores =[],[],[],[]
    for comment, _class, toxic, score in predictions:
        comments.append(comment)
        class_bool = [True if s>threshold else False for s in score  ]
        _class = [l for i,l in enumerate(labels) if class_bool[i]]
        classes.append(_class)
        toxic_list.append(bool(len(_class)))
        scores.append(score)
    return comments, toxic_list, classes, scores

def get_size(start_path = '/tmp/'):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(start_path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            # skip if it is symbolic link
            if not os.path.islink(fp):
                total_size += os.path.getsize(fp)

    return total_size