import json, zipfile, boto3
import unzip_requirements, os, shutil
from utils import *

def lambda_handler(event, context):
    try:
        model_bucket = event.get('queryStringParameters').get('model_bucket')
        model_id  = event.get('queryStringParameters').get('model_id')
        threshold = float(event.get('queryStringParameters').get('threshold',0.5))
        if event.get('queryStringParameters').get('comments'):
            comments_list = event.get('queryStringParameters').get('comments').split('/')
        elif event.get('queryStringParameters').get('item_id'):
            item_id = event.get('queryStringParameters').get('item_id') 
            comments_list, comments_ids, comments_owners  = get_comments(item_id)
        if len(comments_list) == 0:
            return {
            'statusCode': 200,
            'body': json.dumps({'message':'this item does not have comments enabled'})
                    }
            
        if not check_model_artefacts_on_S3(model_bucket, model_id):
            print(get_model_fromAGOL(model_id))
            print(upload_model_to_S3(model_bucket, model_id))
            os.remove(f'/tmp/{model_id}')
            model_name = extract_model_to_s3(model_bucket, model_id)
        else:
            model_name = get_model_name(model_bucket, model_id)

        
        
        for root, dirs, files in os.walk('/tmp/'):
            for f in files:
                if f.endswith('pth') or f.endswith('emd'):
                    continue
                    os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
                

        
        if not os.path.exists(f'/tmp/{model_name}.emd'):
            get_model_artefacts(model_bucket, model_id)
                      
        model, labels = load_model(model_name)
        comments, toxic_list, classes, scores = predict(model, comments_list, labels, threshold)
        result = list(zip(comments, toxic_list, classes))
        
        # sns_arn = os.environ.get('SNS-ARN',False)
        # if event.get('queryStringParameters').get('item_id') and not event.get('queryStringParameters').get('comments') and sns_arn:
        #     message = f'Toxic comments found in AGOL item {item_id}\
        #                 \nItem URL : https://www.arcgis.com/home/item.html?id={item_id}\
        #                 \n\nDetected toxic comments and comment categories\n'
            
        #     toxic_results = [f'{res[0]}  --  {res[2]}' for res in result if res[1]]
        #     for toxic_result in toxic_results:
        #         message += f'\n - {toxic_result}'
        #     print(message)
        #     send_email(message, sns_ar)

    except Exception as e:
        print('\nERROR: ',str(e))
        return {
        'statusCode': 200,
        'body': json.dumps({"error":str(e)})
        }

    return {
    'statusCode': 200,
    'body': json.dumps({id:{'comment': comment,'toxic':toxic,'classes':_classes,'scores':dict(zip(labels,_scores))} 
                        for id,comment,toxic,_classes,_scores \
                        in list(zip(range(len(comments)),comments,toxic_list,classes,scores))})
            }
