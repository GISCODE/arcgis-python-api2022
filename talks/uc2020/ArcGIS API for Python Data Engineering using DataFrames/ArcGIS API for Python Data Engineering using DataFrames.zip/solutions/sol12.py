df['DateTimeWithHours'] = pd.to_datetime(df)
df