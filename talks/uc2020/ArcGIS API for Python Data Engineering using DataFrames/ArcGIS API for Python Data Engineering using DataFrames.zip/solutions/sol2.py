df = pd.DataFrame(data, columns=fields)
df
