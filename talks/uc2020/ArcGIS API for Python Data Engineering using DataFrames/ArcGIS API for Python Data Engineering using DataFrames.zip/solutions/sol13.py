df.index = pd.to_datetime(df[['month','day','year']])
df.loc[pd.to_datetime('2017-12-25')]
