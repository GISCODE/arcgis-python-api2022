df.describe()
