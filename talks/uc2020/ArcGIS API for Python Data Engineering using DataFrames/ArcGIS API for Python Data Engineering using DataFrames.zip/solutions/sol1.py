series = pd.Series(data)
series