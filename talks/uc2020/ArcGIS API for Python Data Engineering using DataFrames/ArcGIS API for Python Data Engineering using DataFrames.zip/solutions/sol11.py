df = (
    df
    .rename(columns=str.lower)
    .assign(
        name=lambda x: x['name'].str.lower()
    )
)

df.head()