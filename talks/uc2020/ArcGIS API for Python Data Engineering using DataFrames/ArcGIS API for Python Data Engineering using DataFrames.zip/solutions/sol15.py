drinks = pd.read_csv(url)
drinks = drinks.astype({'beer_servings' : float, 
                        'spirit_servings' : float,
                        'continent' : 'category'
                       })
drinks.dtypes 
