drinks = pd.read_csv(url, dtype={'continent' : 'category'})
drinks.continent.cat.categories