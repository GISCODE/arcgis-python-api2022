df.dtypes
