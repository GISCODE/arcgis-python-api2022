tidy['rest'] = (
                tidy
                .sort_values('date')
                .groupby('team')
                .date.diff().dt.days - 1
               )
tidy.dropna().head()
