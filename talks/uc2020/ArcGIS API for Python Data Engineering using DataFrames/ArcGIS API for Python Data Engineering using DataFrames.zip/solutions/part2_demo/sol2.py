column_names = {'Date': 'date', 'Start (ET)': 'start',
                'Unamed: 2': 'box', 'Visitor/Neutral': 'away_team', 
                'PTS': 'away_points', 'Home/Neutral': 'home_team',
                'PTS.1': 'home_points', 'Unamed: 7': 'n_ot'}

games = (
             games
             .rename(columns=column_names)
             .rename(columns=str.lower)
             .dropna(thresh=4)
             [['date', 'away_team', 'away_points', 'home_team', 'home_points']]
             .assign(date=lambda x: pd.to_datetime(x['date'], format='%a, %b %d, %Y'))
             .set_index('date', append=True) 
             .rename_axis(["game_id", "date"])
             .sort_index()
        )
games.head()
