data = "./data/sample_data.gdb/Zoning"
sdf = pd.DataFrame.spatial.from_featureclass(data)
sdf.SHAPE.head()
