sdf['centers'] = sdf.SHAPE.geom.centroid
sdf['centers'].head()